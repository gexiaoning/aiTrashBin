var md5 = require('../../../utils/md5.js')
var http = require('../../../utils/http.js')
var util = require('../../../utils/util.js')
// import { Utilaa } from 'util'
// var u = require('underscore')
Page({
  data: {
    accessToken: "",
    isShow: false,
    results: [],
    src: "",
    isCamera: true,
    btnTxt: "photo"
  },
  onLoad() {
    this.ctx = wx.createCameraContext()
    var time = wx.getStorageSync("time")
    var curTime = new Date().getTime()
    var timeInt=parseInt(time)
    var timeNum = parseInt((curTime - timeInt) / (1000 * 60 * 60 * 24))
    console.log("=======" + timeNum) 
    var accessToken = wx.getStorageSync("access_token")
    console.log("====accessToken===" + accessToken + "a")
    if (timeNum > 28 || (accessToken == "" ||
        accessToken == null || accessToken == undefined)) {
      this.accessTokenFunc()
    } else {
      this.setData({
        accessToken: wx.getStorageSync("access_token")
      })
    }
  },
  takePhoto() {
    var that = this
    if (this.data.isCamera == false) {
      this.setData({
        isCamera: true,
        btnTxt: "photo"
      })
      return
    }
    this.ctx.takePhoto({
      quality: 'high',
      success: (res) => {
        this.setData({
          src: res.tempImagePath,
          isCamera: false,
          btnTxt: "retake"
        })
        wx.showLoading({
          title: 'loading',
        })
        wx.getFileSystemManager().readFile({
          filePath: res.tempImagePath,
          encoding: "base64",
          success: res => {
            that.req(that.data.accessToken, res.data)
          },
          fail: res => {
            wx.hideLoading()
            wx.showToast({
              title: 'fail to photo',
              icon: "none"
            })
          }
        })
      }
    })
  },
  req: function(token, image) {
    var that = this
    http.req("https://aip.baidubce.com/rest/2.0/image-classify/v2/advanced_general?access_token=" + token, {
      "image": image
    }, function(res) {
      wx.hideLoading()
      console.log(JSON.stringify(res))
      var code=res.data.err_code 
      if (code == 111 || code == 100 || code==110){
        wx.clearStorageSync("access_token")
        wx.clearStorageSync("time")
        that.accessTokenFunc()
        return
      }

      console.log(res.data.result[0].keyword)
      http.req("http://api.tianapi.com/txapi/lajifenlei/index?key=1a1153f621ff559cbd013e11bd203140&num=1&word=" + res.data.result[0].keyword, null, function(res) {
        console.log(res)
        wx.showModal({
          title: that.translateCode(res.data.newslist[0].type),
          confirmText: res.data.newslist[0].type==1?'Drop off':'I got it',
          cancelText: 'Dismiss',
          success: function(e) {
            if (res.data.newslist[0].type == 1 && e.confirm) {
              wx.navigateTo({
                url: '../../map/map',
              })
            }
          }
        })
      }, "POST")

    }, "POST")
  },

  translateCode: function(type) {
    if (type == 0) {
      return 'Recyclable waste'
    } else if (type == 1) {
      return 'Hazardous waste'
    } else if (type == 2) {
      return 'HouseHoldFood waste'
    } else if (type == 3) {
      return 'Residual waste'
    } else {
      return 'Not Found'
    }
  },
  accessTokenFunc: function() {
    var that = this
    console.log("accessTokenFunc is start")
    wx.cloud.callFunction({
      name: 'baiduAccessToken',
      success: res => {
        console.log("==baiduAccessToken==" + JSON.stringify(res))
        that.data.accessToken = res.result.data.access_token
        wx.setStorageSync("access_token", res.result.data.access_token)
        wx.setStorageSync("time", new Date().getTime())
      },
      fail: err => {
        wx.clearStorageSync("access_token")
        wx.showToast({
          icon: 'none',
          title: '调用失败,请重新尝试',
        })
        console.error('[云函数] [sum] 调用失败：', err)
      }
    })
  },
  radioChange: function(e) {
    console.log(e)
    console.log(e.detail)
    console.log(e.detail.value)
    wx.navigateTo({
      url: '/pages/result/list?keyword=' + e.detail.value,
    })
  },
  hideModal: function() {
    this.setData({
      isShow: false,
    })
  },
  stopRecord() {
    this.ctx.stopRecord({
      success: (res) => {
        this.setData({
          src: res.tempThumbPath,
          videoSrc: res.tempVideoPath
        })
      }
    })
  },
  error(e) {
    console.log(e.detail)
  }

})