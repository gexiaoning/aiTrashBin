var http = require('../../utils/http.js')

Page({

  data: {
    SHOW_TOP: true,
  },

  onLoad: function(options) {
    console.log("AAAAAAAAA")
    var myDate = new Date();
    var isShowed=wx.getStorageSync("tip")
    if(isShowed!=1){
      setTimeout(() => {
        this.setData({
          SHOW_TOP: false
        })
        wx.setStorageSync("tip", 1)
      }, 2 * 1000)
    }else{
      this.setData({
        SHOW_TOP: false
      })
    }
  },

  search: function(e) {
    const that = this
    wx.showLoading({
      title: 'sorting',
    })
    http.req("http://api.tianapi.com/txapi/lajifenlei/index?key=1a1153f621ff559cbd013e11bd203140&num=1&word=" + e.detail.value, null, function(res) {
        wx.hideLoading({
          
        })
        wx.showModal({
          title: that.translateCode(res.data.newslist[0].type),
          confirmText: res.data.newslist[0].type==1?'Drop off':'I got it',
          cancelText: 'Dismiss',
          success: function(e) {
            if (res.data.newslist[0].type == 1 && e.confirm) {
              wx.navigateTo({
                url: '../map/map',
              })
            }
          }
        })
      }, "POST")
  },
  translateCode: function(type) {
    if (type == 0) {
      return 'Recyclable waste'
    } else if (type == 1) {
      return 'Hazardous waste'
    } else if (type == 2) {
      return 'HouseHoldFood waste'
    } else if (type == 3) {
      return 'Residual waste'
    } else {
      return 'Not found'
    }
  },
  onBindCamera: function() {
    wx.navigateTo({
      url: 'camera/camera',
    })
  },
  onAikefu: function() {
    wx.navigateTo({
      url: '/pages/android/qa',
    })
  },
})