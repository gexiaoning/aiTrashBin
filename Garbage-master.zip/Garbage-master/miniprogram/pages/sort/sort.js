const app = getApp();
Page({
  data: {
    ColorList: [
      "../../images/RecycleableWaste.jpg",
      "../../images/HazardouAwaste.jpg",
      "../../images/HouseholdfoodWaste.jpg",
      "../../images/ResidualWaste.png",
    ]
  },
  onLoad:function(){
  },
  goSearch: function () {
    wx.navigateTo({
      url: '/pages/ai/search',
    })
  },
  onClick:function(e){
    var index = e.currentTarget.dataset.index
    switch (index){
      case 0:
        wx.showModal({
          title: "Recycling is the process of converting waste materials into new materials and objects",
          duration: 3000,
          confirmText: 'I got it',
          cancelText: 'Dismiss',
        })
      break;
       case 1:
        wx.showModal({
          title: "Hazardous waste is waste that has substantial or potential threats to public health or the environment",
          duration: 3000,
          confirmText: 'I got it',
          cancelText: 'Dismiss',
        })
      break;
      case 2:
        wx.showModal({
          title: "Food waste or food loss is food that is wasted, lost or uneaten",
          duration: 3000,
          confirmText: 'I got it',
          cancelText: 'Dismiss',
        })
        break;
      case 3:
        wx.showModal({
          title: "Residual waste is nonhazardous industrial waste",
          duration: 3000,
          confirmText: 'I got it',
          cancelText: 'Dismiss',
        })
        break;
    }
    
  }
})