Page({
  data: {
    
    latitude: 37.3496,
    longitude: -121.93,
    markers: [{
      iconPath: "../../images/gd.png",
      id: 0,
      latitude: 37.374941,
      longitude: -121.896903,
      width: 35,
      height: 35,
      title: "Santa Clara County Household Hazardous Waste Program, 1555 Berger Dr Suite #300, San Jose, CA 95112"
    }, {
      iconPath: "../../images/gd.png",
      id: 0,
      latitude: 37.508536,
      longitude: -121.990659,
      width: 35,
      height: 35,
      title: "HazMat Dropoff, 41149 Boyce Rd, Fremont, CA 94538"
    }, {
      iconPath: "../../images/gd.png",
      id: 0,
      latitude: 37.365627,
      longitude: -121.887490,
      width: 35,
      height: 35,
      title: "Clean Harbors Environmental, 1010 Commercial St, San Jose, CA 95112"
    }, {
      iconPath: "../../images/gd.png",
      id: 0,
      latitude: 37.503331,
      longitude: -122.262527,
      width: 35,
      height: 35,
      title: "RethinkWaste, 610 Elm St #202, San Carlos, CA 94070"
    }],
  },
  onLoad: function(e) {
    const that = this
    wx.getLocation({
      type: 'gcj02',
      success (res) {
        
        console.log(that.data)
      }
     })
     
  }
})